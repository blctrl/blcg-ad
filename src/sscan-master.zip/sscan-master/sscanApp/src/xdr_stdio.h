

/**********************************************************/
/*                                                        */
/* xdr stream for standard I/O                            */
/*                                                        */
/*                                                        */
/*                                                        */
/**********************************************************/







void xdrstdio_create(register XDR* xdrs, FILE* file, enum xdr_op op);
