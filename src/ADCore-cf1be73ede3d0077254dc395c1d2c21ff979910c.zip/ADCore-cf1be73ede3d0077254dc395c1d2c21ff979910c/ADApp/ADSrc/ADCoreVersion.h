#ifndef ADCoreVersion_H
#define ADCoreVersion_H

#define ADCORE_VERSION      3
#define ADCORE_REVISION     2
#define ADCORE_MODIFICATION 0

#endif

