In current version of office:
Convert to PDF, then save PDF as PNG in Acrobat.  File/Save As/Image/PNG/Settings to change to 600 DPI.

In older version of office:

To make the PNG file from the PPT file, select the entire page (^A), right click, Save as Picture, select PNG.

Saving the slide as PNG with Save As works, but it is lower resolution so the text is ugly.
