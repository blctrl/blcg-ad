ADmar345
===========
An 
[EPICS](http://www.aps.anl.gov/epics/) 
[areaDetector](http://cars.uchicago.edu/software/epics/areaDetector.html) 
driver for the mar345 detector from 
[Marresearch GmbH](http://www.marresearch.com/).

Additional information:
* [Documentation](http://cars.uchicago.edu/software/epics/Mar345Doc.html).
* [Release notes and links to source and binary releases](RELEASE.md).
